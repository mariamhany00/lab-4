

const Home = () => {
 
  return (
  <>
  <div>Movie Home </div>;
  
  </>
  )
  
};

export default Home;