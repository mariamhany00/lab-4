const NotFoud = () => {
    return <div>NotFoud</div>;
  };
  
  export default NotFoud;