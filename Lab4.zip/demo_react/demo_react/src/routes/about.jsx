const About = () => {
    return <div>About us</div>;
  };
  
  export default About;