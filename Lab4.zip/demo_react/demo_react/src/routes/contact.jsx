// Contact.js
import { useContext } from 'react';
import { LanguageContext } from '../context/context';

const Contact = () => {
  const { lang, toggleLanguage } = useContext(LanguageContext);

  const direction = lang === 'en' ? 'ltr' : 'rtl';
  const buttonText = lang === 'en' ? 'عربي' : 'English';
  const text = lang === 'en' ? englishText : arabicText;

  return (
    <nav style={{ direction: direction }}>
      <button className='btn btn-success' onClick={toggleLanguage}>
        {buttonText}
      </button>
      <p>{text}</p>
    </nav>
  );
};

const englishText = "I love Programming";
const arabicText = "انا احب البرمجة";
export default Contact;


