import './about.css'
function AboutUs() {


    return (
      <>
      <div className="d-flex mt-5">
        <div  className="divone">
            <h1>About Me</h1>
        </div>
        <div  className="divtwo">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi, dignissimos eum ipsum quaerat eos est vero, veniam neque hic tempora, porro totam recusandae sint repellat ab vel dolorum alias odio.</p>
            <button className='btn btn-dark '>Download</button>
        </div>
    </div>
      </>
    )
  }
  
  export default AboutUs