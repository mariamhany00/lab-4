import './header.css'
function Header() {


    return (
      <>
      <div className="header">
        <div className='header_text'>
     <h1 >Katie Reed </h1>
     <p>web devolper & designer</p>
     <button className='btn btn-danger'>Contact Us</button>
     </div>
     </div>
     {/* <img src='/src/assets/blog_post_02.jpg'/> */}
      </>
    )
  }
  
  export default Header